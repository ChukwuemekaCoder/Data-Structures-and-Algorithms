#ifndef __LIST_H
#define __LIST_H

// CSC 255 Fall 2026 – Dr. Wheat
// Program 1 List
// Team 9: Chukwuemeka Obinna and Ojonimi Edime

//******************************************************************************

#include "common.h"

//******************************************************************************

class list {
    private:
	KEY_VALUE *keyValues;
	unsigned int listCapacity;
	unsigned int originalListCapacity;
	unsigned int listCount;
	unsigned int expandSize;
	unsigned int originalExpandSize;
	bool shortenEnabled;

    public:
	list(unsigned int size = 100, unsigned int expandSize = 5);
	list(list *srcList);

	// destructor
	~list();

	bool expand();
	bool insert(KEY_VALUE kv);
	bool add(KEY_VALUE kv);

	bool deleteFirst(KEY_VALUE &kv);
	bool deleteLast(KEY_VALUE &kv);

	void setExpandSize(unsigned int expandSize);
	//Additional comments written by Chukwuemeka Obinna
	unsigned int getExpandSize() const;//changed to const as declared in list.cpp
	void clear();

	bool readAt(unsigned int index, KEY_VALUE &kv) const;
	unsigned int getIndex(int key) const;
	void printIt(int n) const;
	unsigned int getCount() const;
	unsigned int getCapacity() const;

	// part B functions
	bool insertByKey(KEY_VALUE kv);
	bool insertAt(unsigned int index, KEY_VALUE kv);
	bool deleteAt(unsigned int index, KEY_VALUE &kv);
	void printItBackwards(int n) const;
	list *cat(list *list2);
	void shortenList();
	void setShortenEnabled(bool shorten);
	bool getShortenEnabled() const;//changed to const as declared in list.cpp

	void bubbleSort();
	void selectionSort();
	void insertionSort();
	bool isSorted() const;
};

#endif
